import bpy
from bpy.props import StringProperty, BoolProperty, IntProperty
from bpy.utils import register_class, unregister_class
from bpy.types import Operator

import os, signal
import uuid
import tempfile
import subprocess
import sys
from pathlib import Path

from .utils import show_message_box, force_to_object_mode, SBConstants, pbr_selections_to_list, specials_selection_to_list
#from .messages import print_message

class BakeInProgress:
    is_baking = False
    was_error = False

class BackgroundBakeTasks:
    #Non-blender class. BG bake task
    
    active_tasks = []
    completed_tasks = []
    queued_tasks = []
    
    @classmethod
    def get_completed_or_active_bgt_by_pid(cls, pid):
        pid = int(pid)
        
        match = [t for t in cls.completed_tasks if t.pid == pid]
        if len(match) == 0:
            match = [t for t in cls.active_tasks if t.pid == pid]
        assert(len(match)>0)
        match = match[0]
        
        return match
    
    @classmethod
    def get_queued_bgt_by_id(cls, id):
        match = [t for t in cls.queued_tasks if t.id == id]
        assert(len(match) == 1)
        match = match[0]
        
        return match
    
    @classmethod
    def get_bgbake_status(cls, active_bgbake):
        sbp = bpy.context.scene.SimpleBake_Props
        pid = active_bgbake.pid
        path = Path(sbp.bgbake_temp_dir) / "progress" / str(pid)
                            
        try:
            with open(str(path), "r") as progfile:
                progress = int(progfile.readline())
        except:
            #No file yet, as no bake operation has completed yet. Holding message
            progress = 0
        
        active_bgbake.progress = progress
        
        if progress == 100:
            cls.completed_tasks.append(active_bgbake)
            cls.active_tasks.remove(active_bgbake)
            cls.next_please()
        
        return progress
    
    @classmethod
    def next_please(cls):
        if len(cls.active_tasks) == 0 and len(cls.queued_tasks) > 0:
            t = cls.queued_tasks[0]
            cls.active_tasks.append(t)
            cls.queued_tasks.remove(t)
            t.spawn_bg_process()
            return 2
        
        elif len(cls.active_tasks) == 0 and len(cls.queued_tasks) == 0:
            #Nothing happening, kill timer
            return None
        
        else:
            if len(cls.active_tasks)>0: # Just in case
                active_bgt = cls.active_tasks[0]
                cls.get_bgbake_status(active_bgt)
            return 2
    
    def save_file_copy(self):
        sbp = bpy.context.scene.SimpleBake_Props
        unique_id = str(uuid.uuid4())[0:7]
        tmp_dir_path = Path(sbp.bgbake_temp_dir)
        if not os.path.exists(str(tmp_dir_path)):
                os.makedirs(str(tmp_dir_path))
        
        save_path = tmp_dir_path / (unique_id + ".blend")
        
        #Pack dirty images or we lose them on save
        [i.pack() for i in bpy.data.images if i.is_dirty]
        
        bpy.ops.wm.save_as_mainfile(filepath=str(save_path), check_existing=False, copy=True)
        self.initial_save_path = save_path

        return True
    
    def spawn_bg_process(self):
        sbp = bpy.context.scene.SimpleBake_Props
        tmp_dir_path = sbp.bgbake_temp_dir #Already posix path
        
        base_folder_override = Path(bpy.data.filepath).parent.as_posix()
        
        process = subprocess.Popen(
                [bpy.app.binary_path, "--background",str(self.initial_save_path), "--python-expr",
                f"import bpy; import os; from pathlib import Path; orig_file_path = bpy.data.filepath;\
                savepath=str(Path('{tmp_dir_path}') / (str(os.getpid()) + '.blend'));\
                bpy.ops.wm.save_as_mainfile(filepath=str(savepath), check_existing=False);\
                os.remove(orig_file_path);\
                bpy.context.scene.SimpleBake_Props.bgbake_temp_dir = '{tmp_dir_path}';\
                bpy.context.scene.SimpleBake_Props.base_folder_override = '{base_folder_override}';\
                {self.start_command};"],
                shell=False)
        
        self.pid = process.pid
        self.file_path_po = Path(tmp_dir_path) / (str(process.pid) + ".blend")
        
        return True
    
    def __init__(self, name, copy_and_apply, start_command, bg_bake_id):
        
        #Check for queued that need promotion
        bpy.app.timers.register(BackgroundBakeTasks.next_please, first_interval=2)
        
        sbp = bpy.context.scene.SimpleBake_Props
        self.start_command = start_command
        self.save_file_copy()
        self.progress = 0
        if name == "": name = "Untitled"
        self.name = name
        self.copy_and_apply = copy_and_apply
        self.bg_bake_id = bg_bake_id
        #self.hide_source_objects = hide_source_objects
        #self.hide_cage_object = hide_cage_object
        self.pid = 0
        self.id = str(uuid.uuid4())
        
        #Assume queued for now
        self.__class__.queued_tasks.append(self)

        #print_message("BG bake task created")

class SimpleBake_OT_Import_BGBake(Operator):
    """Import baked textures and objects from the background"""
    bl_idname = "simplebake.import_bgbake"
    bl_label = "Import"
    
    pid: StringProperty()
    
    def execute(self, context):
        sbp = bpy.context.scene.SimpleBake_Props
        bgt = BackgroundBakeTasks.get_completed_or_active_bgt_by_pid(self.pid)
        
        force_to_object_mode()
        
        b_img_names = [i.name for i in bpy.data.images]
        b_obj_names = [o.name for o in bpy.data.objects]
        
        savepath = Path(sbp.bgbake_temp_dir) / (self.pid + ".blend")
        savepath = str(savepath) + "/Collection/"
        
        bpy.ops.wm.append(filename="SimpleBake_Bakes_Background", directory=savepath, use_recursive=False, active_collection=False)
        
        sbc = bpy.data.collections["SimpleBake_Bakes_Background"]
        sbc.name = "SimpleBake_Bakes"
        
        #Relocate, as append leaves it in a funny place
        context.scene.collection.children.link(sbc)
        for c in bpy.data.collections:
            if sbc.name in c.children:
                c.children.unlink(sbc)
                if len(c.children) == 0:
                    bpy.data.collections.remove(c)
        
        #If we didn't want the copied and applied object
        if not bgt.copy_and_apply:
            #Delete the objects, and then collection
            for obj in sbc.objects:
                bpy.data.objects.remove(obj)
            bpy.data.collections.remove(sbc)
        
        a_img_names = [i.name for i in bpy.data.images]
        a_obj_names = [o.name for o in bpy.data.objects]
        
        message = []
        message.append(f"Imported - {len(a_img_names) - len(b_img_names)} images")
        message.append(f"Imported - {len(a_obj_names) - len(b_obj_names)} objects")
        
        #Deal with duplicates - This is hacky and not perfect
        for name in b_img_names:
            if name + ".002" in a_img_names:
                bpy.data.images.remove(bpy.data.images[name])
                bpy.data.images[name + ".002"].name = name
            
            elif name + ".001" in a_img_names:
                bpy.data.images.remove(bpy.data.images[name])
                bpy.data.images[name + ".001"].name = name
        
        BackgroundBakeTasks.completed_tasks.remove(bgt)
        
        #Hide source and/or cage object if requested
        for obj in bpy.data.objects:
            if "SB_BG_HIDE" in obj:
                l = obj["SB_BG_HIDE"]
                if bgt.bg_bake_id in l:
                    obj.hide_set(True)

        #Hide source objects if requested
        #new_obj_names = set(a_obj_names) - set(b_obj_names)
        #if bgt.hide_source_objects:
            #for name in new_obj_names:
                #orig_name = name.replace("_Baked", "")
                #[obj.hide_set(True) for obj in bpy.data.objects if obj.name == orig_name]
        
        #Hide cage object if requested
        #if bgt.hide_cage_object:
            #for name in new_obj_names:

        show_message_box(message, "Import complete", icon = 'INFO')
        
        return{'FINISHED'}
    
class SimpleBake_OT_Delete_Queued_BGBake(Operator):
    """Delete a queued background bake"""
    bl_idname = "simplebake.delete_queued_bgbake"
    bl_label = "Delete"
    
    id: StringProperty()
    
    def execute(self, context):
        sbp = bpy.context.scene.SimpleBake_Props
        bgt = BackgroundBakeTasks.get_queued_bgt_by_id(self.id)
        
        BackgroundBakeTasks.queued_tasks.remove(bgt)
        
        return{'FINISHED'}
                
class SimpleBake_OT_Discard_BGBake(Operator):
    """Discard a completed background bake"""
    bl_idname = "simplebake.discard_bgbake"
    bl_label = "Discard"
    
    pid: StringProperty()
    
    def execute(self, context):
        sbp = bpy.context.scene.SimpleBake_Props
        bgt = BackgroundBakeTasks.get_completed_or_active_bgt_by_pid(self.pid)
        pid = bgt.pid
        
        BackgroundBakeTasks.completed_tasks.remove(bgt)
        path = str(bgt.file_path_po)
        try:
            os.remove(path)
            os.remove(path.replace(".blend", ".blend1"))
        except:
            pass
        
        return{'FINISHED'}


class SimpleBake_OT_Kill_Active_BGBake(Operator):
    """Kill an active background bake"""
    bl_idname = "simplebake.kill_active_bgbake"
    bl_label = "Kill"
    
    pid: StringProperty()
    
    def execute(self, context):
        sbp = bpy.context.scene.SimpleBake_Props
        bgt = BackgroundBakeTasks.get_completed_or_active_bgt_by_pid(self.pid)
        pid = bgt.pid
        
        BackgroundBakeTasks.active_tasks.remove(bgt)
        os.kill(pid, signal.SIGTERM)
        
        return{'FINISHED'}
 
class SimpleBake_OT_Update_Progress(Operator):
    bl_idname = "simplebake.update_progress"
    bl_label = "Update"
    
    def execute(self, context):
        
        self.background = True if "--background" in sys.argv else False
        
        sbp = context.scene.SimpleBake_Props
        sbp.current_bake_image_number+=1
        
        percent_complete = (sbp.current_bake_image_number/sbp.total_bake_images_number) *100
        percent_complete = round(percent_complete)
        sbp.percent_complete = percent_complete
        
        if self.background:
            path = Path(sbp.bgbake_temp_dir) / "progress"
            
            if not os.path.exists(str(path)):
                os.makedirs(str(path))
            
            pid = os.getpid()
            path = path / str(pid)
            
            with open(str(path), "w") as progfile:
                progfile.write(str(percent_complete))
        
        return{'FINISHED'}


#Non-Blender class
class BakeProgress:

    def __init__(self, mode, objnum, hl_matches=None):

        sbp = bpy.context.scene.SimpleBake_Props

        udims = True if sbp.uv_mode == "udims" else False
        t=0

        if mode == SBConstants.PBRS2A_DECALS:
            ps = len(pbr_selections_to_list())
            ss = len(specials_selection_to_list())
            u = sbp.udim_tiles if udims else 1

            #The S2A element
            t = (ps+ss) * u * 1
            #The non-S2A element
            t+= ps * u * 1

            sbp.total_bake_images_number = t


        if mode == SBConstants.PBR:
            ps = len(pbr_selections_to_list())
            ss = len(specials_selection_to_list())
            u = sbp.udim_tiles if udims else 1
            t = (ps + ss) * u * objnum

            sbp.total_bake_images_number = t


        if mode == SBConstants.PBRS2A:
            ps = len(pbr_selections_to_list())
            ss = len(specials_selection_to_list())
            u = sbp.udim_tiles if udims else 1
            o = 1 #S2A bake

            t = (ps + ss) * u * o

            sbp.total_bake_images_number = t

        if mode == SBConstants.CYCLESBAKE:
            pass

        if mode == SBConstants.CYCLESBAKE_S2A:
            cb = 1 #CyclesBake
            ss = len(specials_selection_to_list())
            u = sbp.udim_tiles if udims else 1
            objnum = 1 #S2A bake

            t = (cb + ss) * u * objnum

            sbp.total_bake_images_number = t

        if mode in [SBConstants.PBRS2A_AUTOMATCH, SBConstants.CYCLESBAKES2A_AUTOMATCH]:

            #Cycles bake always has only one bake mode
            ps = len(pbr_selections_to_list()) if mode == SBConstants.PBRS2A_AUTOMATCH else 1

            ss = len(specials_selection_to_list())
            u = sbp.udim_tiles if udims else 1
            t = len(hl_matches) * u * (ps + ss)

            sbp.total_bake_images_number = t


classes = ([
    SimpleBake_OT_Update_Progress,
    SimpleBake_OT_Import_BGBake,
    SimpleBake_OT_Delete_Queued_BGBake,
    SimpleBake_OT_Kill_Active_BGBake,
    SimpleBake_OT_Discard_BGBake
        ])

def register():
    
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)

