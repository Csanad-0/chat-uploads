import bpy
from bpy.utils import register_class, unregister_class
from bpy.types import Panel, AddonPreferences, Operator
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty

import webbrowser

from ..auto_update import VersionControl
from ..utils import SBConstants, clean_file_name, get_cs_list


class SimpleBake_Preferences(AddonPreferences):
    # this must match the add-on name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = "SimpleBake"
    

    apikey: StringProperty(name="Sketchfab API Key: ")
    img_name_format: StringProperty(name="Image format string",
        default="%OBJ%_%BATCH%_%BAKEMODE%_%BAKETYPE%")
    
    
    #Aliases
    diffuse_alias: StringProperty(name=SBConstants.PBR_DIFFUSE, default=SBConstants.PBR_DIFFUSE)
    diffuse_cs: EnumProperty(name="", items=get_cs_list, default=5)
    metal_alias: StringProperty(name=SBConstants.PBR_METAL, default=SBConstants.PBR_METAL)
    metal_cs: EnumProperty(name="", items=get_cs_list, default=3)
    roughness_alias: StringProperty(name=SBConstants.PBR_ROUGHNESS, default=SBConstants.PBR_ROUGHNESS)
    roughness_cs: EnumProperty(name="", items=get_cs_list, default=3)
    glossy_alias: StringProperty(name=SBConstants.PBR_GLOSSY, default=SBConstants.PBR_GLOSSY)
    glossy_cs: EnumProperty(name="", items=get_cs_list, default=3)
    normal_alias: StringProperty(name=SBConstants.PBR_NORMAL, default=SBConstants.PBR_NORMAL)
    normal_cs: EnumProperty(name="", items=get_cs_list, default=3)
    transmission_alias: StringProperty(name=SBConstants.PBR_TRANSMISSION, default=SBConstants.PBR_TRANSMISSION)
    transmission_cs: EnumProperty(name="", items=get_cs_list, default=3)
    transmissionrough_alias: StringProperty(name=SBConstants.PBR_TRANSMISSION_ROUGH, default=SBConstants.PBR_TRANSMISSION_ROUGH)
    transmissionrough_cs: EnumProperty(name="", items=get_cs_list, default=3)
    clearcoat_alias: StringProperty(name=SBConstants.PBR_CLEARCOAT, default=SBConstants.PBR_CLEARCOAT)
    clearcoat_cs: EnumProperty(name="", items=get_cs_list, default=3)
    clearcoatrough_alias: StringProperty(name=SBConstants.PBR_CLEARCOAT_ROUGH, default=SBConstants.PBR_CLEARCOAT_ROUGH)
    clearcoatrough_cs: EnumProperty(name="", items=get_cs_list, default=3)
    emission_alias: StringProperty(name=SBConstants.PBR_EMISSION, default=SBConstants.PBR_EMISSION)
    emission_cs: EnumProperty(name="", items=get_cs_list, default=3)
    specular_alias: StringProperty(name=SBConstants.PBR_SPECULAR, default=SBConstants.PBR_SPECULAR)
    specular_cs: EnumProperty(name="", items=get_cs_list, default=3)
    alpha_alias: StringProperty(name=SBConstants.PBR_ALPHA, default=SBConstants.PBR_ALPHA)    
    alpha_cs: EnumProperty(name="", items=get_cs_list, default=3)
    sss_alias: StringProperty(name=SBConstants.PBR_SSS, default=SBConstants.PBR_SSS)
    sss_cs: EnumProperty(name="", items=get_cs_list, default=3)
    ssscol_alias: StringProperty(name=SBConstants.PBR_SSSCOL, default=SBConstants.PBR_SSSCOL)
    ssscol_cs: EnumProperty(name="", items=get_cs_list, default=3)
    displacement_alias: StringProperty(name=SBConstants.PBR_DISPLACEMENT, default=SBConstants.PBR_DISPLACEMENT)
    displacement_cs: EnumProperty(name="", items=get_cs_list, default=3)
    
    ao_alias: StringProperty(name=SBConstants.AO, default=SBConstants.AO)
    ao_cs: EnumProperty(name="", items=get_cs_list, default=3)
    curvature_alias: StringProperty(name=SBConstants.CURVATURE, default=SBConstants.CURVATURE)
    curvature_cs: EnumProperty(name="", items=get_cs_list, default=3)
    thickness_alias: StringProperty(name=SBConstants.THICKNESS, default=SBConstants.THICKNESS)
    thickness_cs: EnumProperty(name="", items=get_cs_list, default=3)
    vertexcol_alias: StringProperty(name=SBConstants.VERTEXCOL, default=SBConstants.VERTEXCOL)
    vertexcol_cs: EnumProperty(name="", items=get_cs_list, default=3)
    colid_alias: StringProperty(name=SBConstants.COLOURID, default=SBConstants.COLOURID)
    colid_cs: EnumProperty(name="", items=get_cs_list, default=3)
    lightmap_alias: StringProperty(name=SBConstants.LIGHTMAP, default=SBConstants.LIGHTMAP)
    lightmap_cs: EnumProperty(name="", items=get_cs_list, default=3)
    
    #Misc tweaks and options
    no_update_check: BoolProperty(
        default=False,
        description="Don't automatically check for updates to SimpleBake. Keep at current installed version"
        )
    ungroup_all_node_groups: BoolProperty(
        default=False,
        description="Unpack all node groups. Used if you have very unusual node setups in your materials. (e.g. Material Output nodes hidden inside node groups). This will hurt performance, but can avoid crashes with some materials that have lots and lots of nested node groups"
        )

    
    @classmethod
    def reset_img_string(cls):
        prefs = bpy.context.preferences.addons["SimpleBake"].preferences
        prefs.property_unset("img_name_format")
        bpy.ops.wm.save_userpref()
        
    @classmethod
    def reset_aliases(cls):
        prefs = bpy.context.preferences.addons["SimpleBake"].preferences
        
        prefs.property_unset("diffuse_alias")
        prefs.property_unset("metal_alias")  
        prefs.property_unset("roughness_alias")  
        prefs.property_unset("normal_alias")  
        prefs.property_unset("transmission_alias")  
        prefs.property_unset("transmissionrough_alias")  
        prefs.property_unset("clearcoat_alias")  
        prefs.property_unset("clearcoatrough_alias")  
        prefs.property_unset("emission_alias")
        prefs.property_unset("specular_alias")  
        prefs.property_unset("alpha_alias")
        prefs.property_unset("displacement_alias")
        prefs.property_unset("sss_alias")
        prefs.property_unset("ssscol_alias")
        prefs.property_unset("ao_alias") 
        prefs.property_unset("curvature_alias") 
        prefs.property_unset("thickness_alias") 
        prefs.property_unset("vertexcol_alias") 
        prefs.property_unset("colid_alias") 
        prefs.property_unset("lightmap_alias")
        
        prefs.property_unset("diffuse_cs")
        prefs.property_unset("metal_cs")  
        prefs.property_unset("roughness_cs")  
        prefs.property_unset("normal_cs")  
        prefs.property_unset("transmission_cs")  
        prefs.property_unset("transmissionrough_cs")  
        prefs.property_unset("clearcoat_cs")  
        prefs.property_unset("clearcoatrough_cs")  
        prefs.property_unset("emission_cs")
        prefs.property_unset("specular_cs")  
        prefs.property_unset("alpha_cs")
        prefs.property_unset("displacement_cs")
        prefs.property_unset("sss_cs")
        prefs.property_unset("ssscol_cs")
        prefs.property_unset("ao_cs") 
        prefs.property_unset("curvature_cs") 
        prefs.property_unset("thickness_cs") 
        prefs.property_unset("vertexcol_cs") 
        prefs.property_unset("colid_cs") 
        prefs.property_unset("lightmap_cs") 

        bpy.ops.wm.save_userpref() 
        
    def get_alias_dict(self):
        alias_dict = {}
        alias_dict[SBConstants.PBR_DIFFUSE] = clean_file_name(self.diffuse_alias)
        alias_dict[SBConstants.PBR_METAL] = clean_file_name(self.metal_alias)
        alias_dict[SBConstants.PBR_ROUGHNESS] = clean_file_name(self.roughness_alias)
        alias_dict[SBConstants.PBR_GLOSSY] = clean_file_name(self.glossy_alias)
        alias_dict[SBConstants.PBR_NORMAL] = clean_file_name(self.normal_alias)
        alias_dict[SBConstants.PBR_TRANSMISSION] = clean_file_name(self.transmission_alias)
        alias_dict[SBConstants.PBR_TRANSMISSION_ROUGH] = clean_file_name(self.transmissionrough_alias)
        alias_dict[SBConstants.PBR_CLEARCOAT] = clean_file_name(self.clearcoat_alias)
        alias_dict[SBConstants.PBR_CLEARCOAT_ROUGH] = clean_file_name(self.clearcoatrough_alias)
        alias_dict[SBConstants.PBR_EMISSION] = clean_file_name(self.emission_alias)
        alias_dict[SBConstants.PBR_SPECULAR] = clean_file_name(self.specular_alias)
        alias_dict[SBConstants.PBR_ALPHA] = clean_file_name(self.alpha_alias)
        alias_dict[SBConstants.PBR_SSS] = clean_file_name(self.sss_alias)
        alias_dict[SBConstants.PBR_SSSCOL] = clean_file_name(self.ssscol_alias)
        alias_dict[SBConstants.PBR_DISPLACEMENT] = clean_file_name(self.displacement_alias)
        alias_dict[SBConstants.AO] = clean_file_name(self.ao_alias)
        alias_dict[SBConstants.CURVATURE] = clean_file_name(self.curvature_alias)
        alias_dict[SBConstants.THICKNESS] = clean_file_name(self.thickness_alias)
        alias_dict[SBConstants.VERTEXCOL] = clean_file_name(self.vertexcol_alias)
        alias_dict[SBConstants.COLOURID] = clean_file_name(self.colid_alias)
        alias_dict[SBConstants.LIGHTMAP] = clean_file_name(self.lightmap_alias)
        
        return alias_dict
    
    def get_cs_dict(self):
        cs_dict = {}
        cs_dict[SBConstants.PBR_DIFFUSE] = self.diffuse_cs
        cs_dict[SBConstants.PBR_METAL] = self.metal_cs
        cs_dict[SBConstants.PBR_ROUGHNESS] = self.roughness_cs
        cs_dict[SBConstants.PBR_GLOSSY] = self.glossy_cs
        cs_dict[SBConstants.PBR_NORMAL] = self.normal_cs
        cs_dict[SBConstants.PBR_TRANSMISSION] = self.transmission_cs
        cs_dict[SBConstants.PBR_TRANSMISSION_ROUGH] = self.transmissionrough_cs
        cs_dict[SBConstants.PBR_CLEARCOAT] = self.clearcoat_cs
        cs_dict[SBConstants.PBR_CLEARCOAT_ROUGH] = self.clearcoatrough_cs
        cs_dict[SBConstants.PBR_EMISSION] = self.emission_cs
        cs_dict[SBConstants.PBR_SPECULAR] = self.specular_cs
        cs_dict[SBConstants.PBR_ALPHA] = self.alpha_cs
        cs_dict[SBConstants.PBR_SSS] = self.sss_cs
        cs_dict[SBConstants.PBR_SSSCOL] = self.ssscol_cs
        cs_dict[SBConstants.PBR_DISPLACEMENT] = self.displacement_cs
        cs_dict[SBConstants.AO] = self.ao_cs
        cs_dict[SBConstants.CURVATURE] = self.curvature_cs
        cs_dict[SBConstants.THICKNESS] = self.thickness_cs
        cs_dict[SBConstants.VERTEXCOL] = self.vertexcol_cs
        cs_dict[SBConstants.COLOURID] = self.colid_cs
        cs_dict[SBConstants.LIGHTMAP] = self.lightmap_cs
        
        return cs_dict
    
    def draw(self, context):
        sbp = context.scene.SimpleBake_Props
        layout = self.layout
        box = layout.box()
        row = box.row()
        row.scale_y = 2
        row.operator("simplebake.release_notes", icon="MOD_WAVE")
        if not VersionControl.at_current:
            row = box.row()
            row.scale_y = 2
            row.alert = True
            if VersionControl.just_updated:
                row.label(text=f"Please restart Blender")
            else:
                row.label(text=f"Version {VersionControl.current_version_str} of SimpleBake is available!")
                row.operator("simplebake.auto_update", icon="MOD_WAVE")

        #Always allow rollback
        row = box.row()
        row.scale_y = 2
        row.operator("simplebake.rollback_update", icon="FILE_REFRESH", text="Rollback to previous version of SimpleBake")
        
        #Support
        box = layout.box()
        row = box.row()
        row.scale_y = 2
        row.operator("simplebake.support", icon="HELP")

        #Discord
        box = layout.box()
        row = box.row()
        row.scale_y = 2
        row.operator("simplebake.discord", icon="OUTLINER_OB_LIGHT")

        
        #Sketchfab
        box = layout.box()
        row = box.row()
        row.label(text="Enter your Sketchfab API key below. Don't forget to click \"Save Preferences\" after.")
        row = box.row()
        row.prop(self, "apikey")
        
        box = layout.box()
        row = box.row()
        row.label(text="Format for baked image names")
        row = box.row()
        row.label(text="Valid variables are %OBJ% (object name or 'MergedBake'), %BATCH% (batch name),")
        row.scale_y = 0.5
        row = box.row()
        row.label(text="%BAKEMODE% (pbr or cycles bake) and %BAKETYPE% (diffuse, emission etc.)")
        row.scale_y = 0.5
        row = box.row()
        
        row = box.row()
        row.prop(self, "img_name_format")
        row = box.row()
        row.operator("simplebake.default_imgname_string")
        
        #PBR Aliases
        box = layout.box()
        
        row = box.row()
        row.label(text="Aliases and colour space settings for PBR bake types")
        
        row = box.row()
        row.label(text="WARNING: Sketchfab looks for certain values. Changing these may break SF Upload")
        
        row = box.row()
        col = row.column()
        col.prop(self, "diffuse_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "diffuse_cs")
        col = row.column()
        col.prop(self, "metal_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "metal_cs")

        row = box.row()
        col = row.column()
        col.prop(self, "sss_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "sss_cs")
        col = row.column()
        col.prop(self, "ssscol_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "ssscol_cs")
        
        row = box.row()
        col = row.column()
        col.prop(self, "roughness_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "roughness_cs")
        col = row.column()
        col.prop(self, "glossy_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "glossy_cs")

        row = box.row()
        col = row.column()
        col.prop(self, "transmission_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "transmission_cs")
        col = row.column()
        col.prop(self, "transmissionrough_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "transmissionrough_cs")

        row = box.row()
        col = row.column()
        col.prop(self, "clearcoat_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "clearcoat_cs")
        col = row.column()
        col.prop(self, "clearcoatrough_alias")  
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "clearcoatrough_cs")

        row = box.row()
        col = row.column()
        col.prop(self, "emission_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "emission_cs")
        col = row.column()
        col.prop(self, "specular_alias") 
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "specular_cs")
        
        row = box.row()
        col = row.column()
        col.prop(self, "alpha_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "alpha_cs")
        col = row.column()
        col.prop(self, "normal_alias") 
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "normal_cs")
        
        row = box.row()
        col = row.column()
        col.prop(self, "displacement_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "displacement_cs")
        col = row.column()
        col.label(text="                       ")
        col.enabled = False
        
        #Specials Aliases
        box = layout.box()
        
        row = box.row()
        row.label(text="Aliases for special bake types")
        
        row = box.row()
        col = row.column()
        col.prop(self, "ao_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "ao_cs")
        col = row.column()
        col.prop(self, "curvature_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "curvature_cs")
        
        row = box.row()
        col = row.column()
        col.prop(self, "thickness_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "thickness_cs")
        col = row.column()
        col.prop(self, "vertexcol_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "vertexcol_cs")

        row = box.row()
        col = row.column()
        col.prop(self, "colid_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "colid_cs")
        col = row.column()
        col.prop(self, "lightmap_alias")
        col = row.column()
        col.alignment = 'RIGHT'
        col.prop(self, "lightmap_cs")
        
        #Reset button
        box = layout.box()
        row = box.row()
        row.operator("simplebake.restore_default_aliases")
        
        box = layout.box()
        row = box.row()
        row.label(text="Tweaks and Misc Options")
        row = box.row()
        row.prop(self, "no_update_check", text="Don't check for SimpleBake updates on Blender start")
        row = box.row()
        row.prop(self, "ungroup_all_node_groups", text="Unpack ALL node groups in materials")

        
        
class SimpleBake_OT_restore_default_aliases(Operator):
    """Reset the image name aliases"""
    bl_idname = "simplebake.restore_default_aliases"
    bl_label = "Restore all aliases and colour space settings to default"
    
    def execute(self, context):
        SimpleBake_Preferences.reset_aliases()
        return {'FINISHED'} 

class SimpleBake_OT_default_imgname_string(Operator):
    """Reset the image name string to default (Sketchfab compatible)"""
    bl_idname = "simplebake.default_imgname_string"
    bl_label = "Restore image string to default"
    
    def execute(self, context):
        SimpleBake_Preferences.reset_img_string()
        
        return {'FINISHED'} 

class SimpleBake_OT_Release_Notes(Operator):
    """View the SimpleBake Release Notes"""
    bl_idname = "simplebake.release_notes"
    bl_label = "View the SimpleBake Release Notes"
    
    def execute(self, context):
        webbrowser.open('http://www.toohey.co.uk/SimpleBake/releasenotes3.html', new=2)
        return {'FINISHED'}  

class SimpleBake_OT_Support(Operator):
    """Open the SimpleBake Support Page"""
    bl_idname = "simplebake.support"
    bl_label = "Open the SimpleBake Support Page"
    
    def execute(self, context):
        webbrowser.open('http://www.toohey.co.uk/SimpleBake/support', new=2)
        return {'FINISHED'}

class SimpleBake_OT_Discord(Operator):
    """Open the SimpleBake Discord"""
    bl_idname = "simplebake.discord"
    bl_label = "Open the SimpleBake Discord"

    def execute(self, context):
        webbrowser.open('https://discord.gg/F6rrW2YS', new=2)
        return {'FINISHED'}

classes = ([
        SimpleBake_Preferences,
        SimpleBake_OT_Release_Notes,
        SimpleBake_OT_Support,
        SimpleBake_OT_restore_default_aliases,
        SimpleBake_OT_default_imgname_string,
        SimpleBake_OT_Discord
        ])

def register():
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
