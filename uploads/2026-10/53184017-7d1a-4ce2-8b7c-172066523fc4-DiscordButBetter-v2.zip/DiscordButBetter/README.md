# DiscordButBetter

Electron + Firebase (Auth + Realtime Database) chat with unique `Name#1234` usernames,
friend requests, persistent 1-on-1 messages and a Discord-style dark UI.

## Run

    npm install
    npm start

## One-time Firebase setup

1. Console -> Authentication -> Sign-in method -> enable **Email/Password**.
2. Console -> Realtime Database -> **Rules** -> paste `database.rules.json` -> Publish.
   (Or `firebase deploy --only database` if you use the Firebase CLI.)

The old `named_messages` node and `users/*/friends` data from the previous version are
no longer used (the new rules block them). Delete them whenever you like.

## Layout

    src/main/main.js          Electron main process (window, screen-capture IPC)
    src/main/preload.js       Safe bridge exposed to the renderer
    src/renderer/index.html   Markup
    src/renderer/styles.css   Discord-style theme
    src/renderer/renderer.js  Entry point: wires the UI to the modules below
    src/renderer/js/          firebase, auth, friends, chat, media, ui, state, utils
    database.rules.json       Security rules
