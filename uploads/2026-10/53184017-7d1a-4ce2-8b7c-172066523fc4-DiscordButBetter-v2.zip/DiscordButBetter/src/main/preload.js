'use strict';

const { contextBridge, ipcRenderer } = require('electron');

// The only native capability the renderer gets.
contextBridge.exposeInMainWorld('native', {
  getCaptureSources: () => ipcRenderer.invoke('capture:get-sources'),
});
