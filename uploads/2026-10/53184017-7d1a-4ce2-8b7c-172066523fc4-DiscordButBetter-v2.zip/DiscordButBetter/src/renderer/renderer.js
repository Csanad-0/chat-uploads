// Entry point: wires the DOM to the auth / friends / chat / media modules.
import { watchAuth, login, register, logout, authErrorMessage } from './js/auth.js';
import { session, setSession, resetSession } from './js/state.js';
import * as friendsApi from './js/friends.js';
import * as chatApi from './js/chat.js';
import * as media from './js/media.js';
import * as ui from './js/ui.js';
import { $, $$ } from './js/utils.js';

ui.hydrateIcons();

/* ------------------------------------------------------------------ state */
let authMode = 'login';
let friends = [];
let activeFriend = null;
let stopConversation = null;
let oldestId = null;
const unsubscribers = [];

const nameOf = (uid) => (uid === session.uid ? session.username : activeFriend?.username ?? 'Unknown');
const reportError = (err) => ui.toast(err?.message || 'Something went wrong.', 'error');

/* ------------------------------------------------------------------- auth */
function setAuthMode(next) {
  authMode = next;
  const registering = next === 'register';
  $('#username-field').hidden = !registering;
  $('#auth-title').textContent = registering ? 'Create an account' : 'Welcome back!';
  $('#auth-subtitle').textContent = registering
    ? 'Pick a username. Leave off the #tag and we will add one.'
    : "We're so excited to see you again!";
  $('#auth-submit').textContent = registering ? 'Continue' : 'Log In';
  $('#auth-switch-text').textContent = registering ? 'Already have an account?' : 'Need an account?';
  $('#auth-switch').textContent = registering ? 'Log In' : 'Register';
  $('#auth-error').textContent = '';
}

$('#auth-switch').addEventListener('click', () => setAuthMode(authMode === 'login' ? 'register' : 'login'));

$('#auth-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const email = $('#auth-email').value;
  const password = $('#auth-password').value;
  const submit = $('#auth-submit');
  $('#auth-error').textContent = '';
  submit.disabled = true;
  try {
    if (authMode === 'register') {
      await register({ username: $('#auth-username').value, email, password });
    } else {
      await login(email, password);
    }
    $('#auth-password').value = '';
  } catch (err) {
    $('#auth-error').textContent = authErrorMessage(err);
  } finally {
    submit.disabled = false;
  }
});

$('#logout-btn').addEventListener('click', () => logout());

watchAuth({
  onSignedIn(profile) {
    if (session.uid === profile.uid) return;
    setSession(profile);
    ui.setMe(profile.username);
    ui.showApp();
    startSubscriptions(profile.uid);
    showFriendsView();
  },
  onSignedOut() {
    unsubscribers.splice(0).forEach((stop) => stop());
    closeChat();
    friends = [];
    resetSession();
    ui.showAuth();
  },
  onError(err) {
    ui.showAuth();
    $('#auth-error').textContent = authErrorMessage(err);
  },
});

/* ---------------------------------------------------------------- friends */
const friendHandlers = { onChat: openChat, onRemove: removeFriend };

function startSubscriptions(uid) {
  unsubscribers.push(
    friendsApi.watchFriends(
      uid,
      (list) => {
        friends = list;
        ui.renderAllFriends(friends, friendHandlers);
        ui.renderDmList(friends, activeFriend?.uid ?? null, openChat);
        if (activeFriend && !friends.some((f) => f.uid === activeFriend.uid)) showFriendsView();
      },
      reportError
    ),
    friendsApi.watchIncoming(
      uid,
      (list) => {
        ui.renderIncoming(list, {
          onAccept: (r) =>
            friendsApi
              .acceptRequest({ uid: r.uid, username: r.fromUsername })
              .then(() => ui.toast(`You and ${r.fromUsername} are now friends!`, 'success'))
              .catch(reportError),
          onDecline: (r) => friendsApi.declineRequest(r.uid).catch(reportError),
        });
        ui.setPendingBadge(list.length);
      },
      reportError
    ),
    friendsApi.watchOutgoing(
      uid,
      (list) =>
        ui.renderOutgoing(list, {
          onCancel: (r) => friendsApi.cancelRequest(r.uid).catch(reportError),
        }),
      reportError
    )
  );
}

function removeFriend(friend) {
  if (!confirm(`Remove ${friend.username} from your friends?`)) return;
  friendsApi.removeFriend(friend.uid).catch(reportError);
}

$$('.tab[data-tab]').forEach((btn) => btn.addEventListener('click', () => ui.showTab(btn.dataset.tab)));
$('#nav-friends').addEventListener('click', showFriendsView);
$('#rail-home').addEventListener('click', showFriendsView);

$('#add-friend-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const input = $('#add-friend-input');
  const msg = $('#add-friend-msg');
  const value = input.value.trim();
  if (!value) return;
  msg.className = 'form-msg';
  msg.textContent = 'Sending…';
  try {
    const result = await friendsApi.sendFriendRequest(value);
    msg.className = 'form-msg success';
    msg.textContent = result.accepted
      ? `${result.username} had already asked you, so you are now friends!`
      : `Friend request sent to ${result.username}.`;
    input.value = '';
  } catch (err) {
    msg.className = 'form-msg error';
    msg.textContent = err.message;
  }
});

/* ------------------------------------------------------------------- chat */
function showFriendsView() {
  closeChat();
  ui.showView('friends');
}

function closeChat() {
  stopConversation?.();
  stopConversation = null;
  stopAllMedia();
  activeFriend = null;
  oldestId = null;
  ui.renderDmList(friends, null, openChat);
}

function openChat(friend) {
  if (activeFriend?.uid === friend.uid) {
    ui.showView('chat');
    return;
  }
  stopConversation?.();
  stopAllMedia();

  activeFriend = friend;
  oldestId = null;
  ui.setChatHeader(friend.username);
  ui.resetConversation();
  ui.showView('chat');
  ui.renderDmList(friends, friend.uid, openChat);

  stopConversation = chatApi.openConversation(session.uid, friend.uid, {
    onHistory: (messages, hasMore) => {
      oldestId = messages[0]?.id ?? null;
      ui.renderHistory(messages, hasMore, nameOf);
    },
    onMessage: (m) => ui.appendMessage(m, nameOf(m.from), m.from === session.uid),
    onRemoved: (id) => ui.removeMessage(id),
    onError: () => ui.toast('Could not load this conversation.', 'error'),
  });
  $('#message-input').focus();
}

$('#composer').addEventListener('submit', async (event) => {
  event.preventDefault();
  const input = $('#message-input');
  const text = input.value.trim();
  if (!text || !activeFriend) return;
  input.value = '';
  try {
    await chatApi.sendMessage(session.uid, activeFriend.uid, text);
  } catch {
    ui.toast('Message failed to send.', 'error');
    if (!input.value) input.value = text;
  }
});

$('#older-btn').addEventListener('click', async () => {
  if (!activeFriend || !oldestId) return;
  const friend = activeFriend;
  const btn = $('#older-btn');
  btn.disabled = true;
  try {
    const { messages, hasMore } = await chatApi.loadOlder(session.uid, friend.uid, oldestId);
    if (activeFriend?.uid !== friend.uid) return; // switched chats meanwhile
    if (messages.length) oldestId = messages[0].id;
    ui.prependHistory(messages, hasMore, nameOf);
  } catch (err) {
    reportError(err);
  } finally {
    btn.disabled = false;
  }
});

$('#btn-remove-friend').addEventListener('click', () => activeFriend && removeFriend(activeFriend));

/* -------------------------------------------------- screen share / camera */
// Local preview only: nothing here is sent to the friend (that needs WebRTC signalling).
const streams = { screen: null, camera: null };
const tiles = {
  screen: { tile: '#screen-tile', video: '#screen-video', button: '#btn-screen' },
  camera: { tile: '#camera-tile', video: '#camera-video', button: '#btn-camera' },
};

function refreshDock() {
  $('#media-dock').hidden = !(streams.screen || streams.camera);
}

function stopMedia(kind) {
  media.stopStream(streams[kind]);
  streams[kind] = null;
  const t = tiles[kind];
  $(t.video).srcObject = null;
  $(t.tile).hidden = true;
  $(t.button).classList.remove('active');
  refreshDock();
}

function stopAllMedia() {
  stopMedia('screen');
  stopMedia('camera');
}

function attachMedia(kind, stream) {
  streams[kind] = stream;
  const t = tiles[kind];
  $(t.video).srcObject = stream;
  $(t.tile).hidden = false;
  $(t.button).classList.add('active');
  stream.getVideoTracks()[0]?.addEventListener('ended', () => {
    if (streams[kind] === stream) stopMedia(kind); // e.g. stopped from the OS sharing bar
  });
  refreshDock();
}

$('#btn-screen').addEventListener('click', async () => {
  if (streams.screen) return stopMedia('screen');
  try {
    const sources = await window.native.getCaptureSources();
    if (!sources.length) {
      ui.toast('No screens found. On macOS, allow Screen Recording for this app.', 'error');
      return;
    }
    const sourceId = await ui.pickSource(sources);
    if (!sourceId) return;
    attachMedia('screen', await media.getScreenStream(sourceId));
  } catch (err) {
    console.error(err);
    ui.toast('Could not start screen sharing.', 'error');
  }
});

$('#btn-camera').addEventListener('click', async () => {
  if (streams.camera) return stopMedia('camera');
  try {
    attachMedia('camera', await media.getCameraStream());
  } catch (err) {
    console.error(err);
    ui.toast('Could not access the camera.', 'error');
  }
});

$('#stop-screen').addEventListener('click', () => stopMedia('screen'));
$('#stop-camera').addEventListener('click', () => stopMedia('camera'));

setAuthMode('login');
