// Who is signed in right now.
export const session = { uid: null, username: null, email: null };

export function setSession({ uid, username, email }) {
  session.uid = uid;
  session.username = username;
  session.email = email;
}

export function resetSession() {
  setSession({ uid: null, username: null, email: null });
}
