// Single place that talks to the Firebase SDK. Every other module imports from here.
//
// The SDK is loaded as ES modules from Google's CDN (no bundler needed). To change
// the SDK version, replace "10.14.1" in the URLs below.
//
// NOTE: a Firebase web apiKey is an identifier, not a secret. What protects your data
// is database.rules.json -- publish it (see README.md).

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  deleteUser,
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  getDatabase,
  ref,
  get,
  update,
  push,
  onValue,
  onChildAdded,
  onChildRemoved,
  query,
  orderByKey,
  limitToLast,
  startAfter,
  endBefore,
  serverTimestamp,
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js';

const firebaseConfig = {
  apiKey: 'AIzaSyDhm1F5X6zF8egujKkg3TCIxIncwbQCcXc',
  authDomain: 'chatdatabase-624b5.firebaseapp.com',
  databaseURL: 'https://chatdatabase-624b5-default-rtdb.europe-west1.firebasedatabase.app',
  projectId: 'chatdatabase-624b5',
  storageBucket: 'chatdatabase-624b5.firebasestorage.app',
  messagingSenderId: '766782716457',
  appId: '1:766782716457:web:20d5e389e101ef2c38ba38',
  measurementId: 'G-SZTWJT68H7',
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getDatabase(app);

export {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  deleteUser,
  ref,
  get,
  update,
  push,
  onValue,
  onChildAdded,
  onChildRemoved,
  query,
  orderByKey,
  limitToLast,
  startAfter,
  endBefore,
  serverTimestamp,
};
