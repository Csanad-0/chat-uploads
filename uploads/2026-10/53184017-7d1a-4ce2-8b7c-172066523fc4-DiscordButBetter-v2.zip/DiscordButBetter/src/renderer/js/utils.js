export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

/** "Name" or "Name#1234" -> { name, tag|null }, or null when invalid. */
export function parseUsername(input, { requireTag = false } = {}) {
  const m = /^\s*([A-Za-z0-9_-]{2,20})(?:#(\d{4}))?\s*$/.exec(input || '');
  if (!m) return null;
  if (requireTag && !m[2]) return null;
  return { name: m[1], tag: m[2] || null };
}

export const randomTag = () => String(1 + Math.floor(Math.random() * 9999)).padStart(4, '0');

/** Database key for the username index. "#" is illegal in RTDB keys, so it becomes "~". */
export const usernameKey = (username) => username.toLowerCase().replace('#', '~');

/** Database key for the email index ("." and friends are illegal in RTDB keys). */
export const emailKey = (email) =>
  email
    .trim()
    .toLowerCase()
    .replace(/[%.$#\[\]\/]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0'));

const AVATAR_COLORS = ['#5865f2', '#3ba55d', '#faa81a', '#ed4245', '#eb459e', '#747f8d'];

export function avatarColor(seed = '') {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

export const initialOf = (username = '?') => username.trim().charAt(0).toUpperCase() || '?';

export function formatTimestamp(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return `Today at ${time}`;
  const yesterday = new Date(Date.now() - 86400000);
  if (d.toDateString() === yesterday.toDateString()) return `Yesterday at ${time}`;
  return `${d.toLocaleDateString()} ${time}`;
}
