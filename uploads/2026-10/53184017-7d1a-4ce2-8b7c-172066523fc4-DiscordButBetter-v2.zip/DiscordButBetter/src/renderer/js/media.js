// Local capture helpers for the screen-share / camera buttons.

export const getScreenStream = (sourceId) =>
  navigator.mediaDevices.getUserMedia({
    audio: false,
    video: {
      mandatory: {
        chromeMediaSource: 'desktop',
        chromeMediaSourceId: sourceId,
        maxFrameRate: 30,
      },
    },
  });

export const getCameraStream = () =>
  navigator.mediaDevices.getUserMedia({
    audio: false,
    video: { width: { ideal: 1280 }, height: { ideal: 720 } },
  });

export function stopStream(stream) {
  if (stream) stream.getTracks().forEach((track) => track.stop());
}
