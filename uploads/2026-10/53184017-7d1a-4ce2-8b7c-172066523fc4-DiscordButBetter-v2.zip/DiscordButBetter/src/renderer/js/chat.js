import {
  db,
  ref,
  get,
  push,
  query,
  orderByKey,
  limitToLast,
  startAfter,
  endBefore,
  onChildAdded,
  onChildRemoved,
  serverTimestamp,
} from './firebase.js';

const PAGE_SIZE = 50;

// One conversation lives at dms/{smallerUid}/{largerUid}/messages/{pushId}.
// Sorting the uids means both people always use the same path.
function messagesRef(uidA, uidB) {
  const [a, b] = [uidA, uidB].sort();
  return ref(db, `dms/${a}/${b}/messages`);
}

const toMessage = (snap) => ({ id: snap.key, ...snap.val() });

function readPage(q) {
  return get(q).then((snap) => {
    const messages = [];
    snap.forEach((child) => {
      messages.push(toMessage(child));
    });
    return messages;
  });
}

export function sendMessage(myUid, otherUid, text) {
  return push(messagesRef(myUid, otherUid), { from: myUid, text, timestamp: serverTimestamp() });
}

/**
 * Open a conversation: load the latest page of history once, then listen only for messages
 * newer than that. The two phases never overlap, and a Set guards against any repeat delivery,
 * so nothing is rendered twice. Returns a function that stops everything.
 */
export function openConversation(myUid, otherUid, { onHistory, onMessage, onRemoved, onError }) {
  const base = messagesRef(myUid, otherUid);
  let active = true;
  const stops = [];

  (async () => {
    try {
      const history = await readPage(query(base, orderByKey(), limitToLast(PAGE_SIZE)));
      if (!active) return;
      onHistory(history, history.length === PAGE_SIZE);

      const seen = new Set(history.map((m) => m.id));
      const lastId = history.length ? history[history.length - 1].id : null;
      const live = lastId ? query(base, orderByKey(), startAfter(lastId)) : base;

      stops.push(
        onChildAdded(
          live,
          (snap) => {
            if (!active || seen.has(snap.key)) return;
            seen.add(snap.key);
            onMessage(toMessage(snap));
          },
          (err) => active && onError(err)
        ),
        // A send the server rejects is rolled back locally; remove it from the screen too.
        onChildRemoved(base, (snap) => active && onRemoved(snap.key))
      );
    } catch (err) {
      if (active) onError(err);
    }
  })();

  return () => {
    active = false;
    stops.splice(0).forEach((stop) => stop());
  };
}

/** The page of messages immediately before `beforeId`. */
export async function loadOlder(myUid, otherUid, beforeId) {
  const messages = await readPage(
    query(messagesRef(myUid, otherUid), orderByKey(), endBefore(beforeId), limitToLast(PAGE_SIZE))
  );
  return { messages, hasMore: messages.length === PAGE_SIZE };
}
