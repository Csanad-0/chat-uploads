import { db, ref, get, update, onValue, serverTimestamp } from './firebase.js';
import { parseUsername, usernameKey, emailKey } from './utils.js';
import { session } from './state.js';

const fail = (message) => {
  throw new Error(message);
};

/** Turn raw Firebase permission errors into something a person can act on. */
async function guarded(fn) {
  try {
    return await fn();
  } catch (err) {
    if (/PERMISSION_DENIED/i.test(`${err?.code} ${err?.message}`)) {
      fail('Permission denied. Make sure database.rules.json is published in the Firebase console.');
    }
    throw err;
  }
}

/** "Name#1234" or an email address -> { uid, username } */
export function resolveUser(input) {
  return guarded(async () => {
    const q = input.trim();
    let uid = null;

    if (q.includes('@')) {
      uid = (await get(ref(db, `emails/${emailKey(q)}`))).val();
    } else {
      const parsed = parseUsername(q, { requireTag: true });
      if (!parsed) fail('Enter a full username like Name#1234, or an email address.');
      uid = (await get(ref(db, `usernames/${usernameKey(`${parsed.name}#${parsed.tag}`)}`))).val();
    }

    const profile = uid ? (await get(ref(db, `users/${uid}`))).val() : null;
    if (!profile?.username) fail("We couldn't find anyone with that username or email.");
    return { uid, username: profile.username };
  });
}

export function sendFriendRequest(input) {
  return guarded(async () => {
    const me = session;
    const target = await resolveUser(input);
    if (target.uid === me.uid) fail("You can't add yourself.");

    const [friend, sent, incoming] = await Promise.all([
      get(ref(db, `friends/${me.uid}/${target.uid}`)),
      get(ref(db, `sentRequests/${me.uid}/${target.uid}`)),
      get(ref(db, `friendRequests/${me.uid}/${target.uid}`)),
    ]);

    if (friend.exists()) fail(`You're already friends with ${target.username}.`);
    if (incoming.exists()) {
      // They already asked us: sending a request back just accepts theirs.
      await acceptRequest({ uid: target.uid, username: target.username });
      return { accepted: true, username: target.username };
    }
    if (sent.exists()) fail(`You've already sent ${target.username} a request.`);

    await update(ref(db), {
      [`friendRequests/${target.uid}/${me.uid}`]: { fromUsername: me.username, createdAt: serverTimestamp() },
      [`sentRequests/${me.uid}/${target.uid}`]: { toUsername: target.username, createdAt: serverTimestamp() },
    });
    return { accepted: false, username: target.username };
  });
}

/** `from` = { uid, username } of the person who sent the request. */
export function acceptRequest(from) {
  const me = session;
  return guarded(() =>
    update(ref(db), {
      [`friends/${me.uid}/${from.uid}`]: { username: from.username, since: serverTimestamp() },
      [`friends/${from.uid}/${me.uid}`]: { username: me.username, since: serverTimestamp() },
      [`friendRequests/${me.uid}/${from.uid}`]: null,
      [`sentRequests/${from.uid}/${me.uid}`]: null,
    })
  );
}

export function declineRequest(fromUid) {
  const me = session;
  return guarded(() =>
    update(ref(db), {
      [`friendRequests/${me.uid}/${fromUid}`]: null,
      [`sentRequests/${fromUid}/${me.uid}`]: null,
    })
  );
}

export function cancelRequest(toUid) {
  const me = session;
  return guarded(() =>
    update(ref(db), {
      [`sentRequests/${me.uid}/${toUid}`]: null,
      [`friendRequests/${toUid}/${me.uid}`]: null,
    })
  );
}

export function removeFriend(friendUid) {
  const me = session;
  return guarded(() =>
    update(ref(db), {
      [`friends/${me.uid}/${friendUid}`]: null,
      [`friends/${friendUid}/${me.uid}`]: null,
    })
  );
}

function toList(snapshot) {
  const out = [];
  snapshot.forEach((child) => {
    out.push({ uid: child.key, ...child.val() });
  });
  return out;
}

const byName = (key) => (a, b) => (a[key] || '').localeCompare(b[key] || '');
const newestFirst = (a, b) => (b.createdAt || 0) - (a.createdAt || 0);

// Each watcher returns an unsubscribe function.
export const watchFriends = (uid, cb, onError) =>
  onValue(ref(db, `friends/${uid}`), (s) => cb(toList(s).sort(byName('username'))), onError);

export const watchIncoming = (uid, cb, onError) =>
  onValue(ref(db, `friendRequests/${uid}`), (s) => cb(toList(s).sort(newestFirst)), onError);

export const watchOutgoing = (uid, cb, onError) =>
  onValue(ref(db, `sentRequests/${uid}`), (s) => cb(toList(s).sort(newestFirst)), onError);
