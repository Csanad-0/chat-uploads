// DOM rendering helpers. No Firebase in here: data goes in, elements come out.
import { $, $$, avatarColor, initialOf, formatTimestamp } from './utils.js';

/* ---------- icons (Material Design paths) ---------- */
const ICONS = {
  chat: 'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z',
  people:
    'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z',
  video: 'M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z',
  screen:
    'M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.11-.9-2-2-2H4c-1.11 0-2 .89-2 2v10c0 1.1.89 2 2 2H0v2h24v-2h-4zm-7-3.53v-2.19c-2.78 0-4.61.85-6 2.72.56-2.67 2.11-5.33 6-5.87V7l4 3.73-4 3.74z',
  logout: 'M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z',
  check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
  close: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
  remove:
    'M14 8c0-2.21-1.79-4-4-4S6 5.79 6 8s1.79 4 4 4 4-1.79 4-4zm3 6v2h6v-2h-6zM2 18v2h16v-2c0-2.66-5.33-4-8-4s-8 1.34-8 4z',
};

const SVG_NS = 'http://www.w3.org/2000/svg';

export function icon(name) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('class', 'icon');
  svg.setAttribute('aria-hidden', 'true');
  const path = document.createElementNS(SVG_NS, 'path');
  path.setAttribute('d', ICONS[name]);
  path.setAttribute('fill', 'currentColor');
  svg.append(path);
  return svg;
}

/** Fill every <span data-icon="name"> with its SVG. */
export function hydrateIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach((node) => node.replaceChildren(icon(node.dataset.icon)));
}

/* ---------- small building blocks ---------- */
export function makeAvatar(username, size = '') {
  const el = document.createElement('div');
  el.className = size ? `avatar ${size}` : 'avatar';
  el.textContent = initialOf(username);
  el.style.background = avatarColor(username);
  return el;
}

export function toast(text, kind = 'info') {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = text;
  $('#toasts').append(el);
  setTimeout(() => el.classList.add('out'), 3500);
  setTimeout(() => el.remove(), 4000);
}

function splitName(username) {
  const i = username.lastIndexOf('#');
  return i < 0 ? [username, ''] : [username.slice(0, i), username.slice(i)];
}

function emptyItem(text) {
  const li = document.createElement('li');
  li.className = 'empty';
  li.textContent = text;
  return li;
}

function userRow({ username, subtitle, actions = [], onClick }) {
  const li = document.createElement('li');
  li.className = 'user-row';
  li.append(makeAvatar(username));

  const info = document.createElement('div');
  info.className = 'user-row-info';
  const [base, tag] = splitName(username);
  const name = document.createElement('div');
  name.className = 'user-row-name';
  const tagEl = document.createElement('span');
  tagEl.className = 'user-row-tag';
  tagEl.textContent = tag;
  name.append(base, tagEl);
  info.append(name);
  if (subtitle) {
    const sub = document.createElement('div');
    sub.className = 'user-row-sub';
    sub.textContent = subtitle;
    info.append(sub);
  }
  li.append(info);

  if (actions.length) {
    const box = document.createElement('div');
    box.className = 'user-row-actions';
    for (const action of actions) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `round-btn ${action.kind || ''}`.trim();
      btn.title = action.title;
      btn.append(icon(action.icon));
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        action.run();
      });
      box.append(btn);
    }
    li.append(box);
  }

  if (onClick) {
    li.classList.add('clickable');
    li.addEventListener('click', onClick);
  }
  return li;
}

/* ---------- screens & views ---------- */
export function showAuth() {
  $('#app').hidden = true;
  $('#auth-screen').hidden = false;
}

export function showApp() {
  $('#auth-screen').hidden = true;
  $('#app').hidden = false;
}

export function showView(name) {
  $('#friends-view').hidden = name !== 'friends';
  $('#chat-view').hidden = name !== 'chat';
  $('#nav-friends').classList.toggle('active', name === 'friends');
}

export function showTab(name) {
  $$('.tab[data-tab]').forEach((btn) => btn.classList.toggle('active', btn.dataset.tab === name));
  $$('.tab-panel').forEach((panel) => {
    panel.hidden = panel.id !== `tab-${name}`;
  });
}

export function setMe(username) {
  $('#me-name').textContent = username;
  $('#me-avatar-slot').replaceChildren(makeAvatar(username));
}

/* ---------- friends ---------- */
export function renderAllFriends(friends, { onChat, onRemove }) {
  $('#all-count').textContent = `All friends — ${friends.length}`;
  const list = $('#friends-list');
  if (!friends.length) {
    list.replaceChildren(emptyItem('No friends yet. Open “Add Friend” to send your first request.'));
    return;
  }
  list.replaceChildren(
    ...friends.map((f) =>
      userRow({
        username: f.username,
        subtitle: 'Friend',
        onClick: () => onChat(f),
        actions: [
          { icon: 'chat', title: 'Message', run: () => onChat(f) },
          { icon: 'remove', title: 'Remove friend', kind: 'danger', run: () => onRemove(f) },
        ],
      })
    )
  );
}

export function renderDmList(friends, activeUid, onOpen) {
  const list = $('#dm-list');
  if (!friends.length) {
    list.replaceChildren(emptyItem('No conversations yet'));
    return;
  }
  list.replaceChildren(
    ...friends.map((f) => {
      const li = document.createElement('li');
      li.className = `dm-item${f.uid === activeUid ? ' active' : ''}`;
      const label = document.createElement('span');
      label.className = 'dm-name';
      label.textContent = f.username;
      li.append(makeAvatar(f.username, 'sm'), label);
      li.addEventListener('click', () => onOpen(f));
      return li;
    })
  );
}

export function renderIncoming(requests, { onAccept, onDecline }) {
  $('#incoming-count').textContent = `Incoming — ${requests.length}`;
  const list = $('#incoming-list');
  if (!requests.length) {
    list.replaceChildren(emptyItem('No pending friend requests.'));
    return;
  }
  list.replaceChildren(
    ...requests.map((r) =>
      userRow({
        username: r.fromUsername,
        subtitle: 'Incoming friend request',
        actions: [
          { icon: 'check', title: 'Accept', kind: 'accept', run: () => onAccept(r) },
          { icon: 'close', title: 'Decline', kind: 'danger', run: () => onDecline(r) },
        ],
      })
    )
  );
}

export function renderOutgoing(requests, { onCancel }) {
  $('#outgoing-count').textContent = `Outgoing — ${requests.length}`;
  const list = $('#outgoing-list');
  if (!requests.length) {
    list.replaceChildren(emptyItem('You have no outgoing requests.'));
    return;
  }
  list.replaceChildren(
    ...requests.map((r) =>
      userRow({
        username: r.toUsername,
        subtitle: 'Outgoing friend request',
        actions: [{ icon: 'close', title: 'Cancel request', kind: 'danger', run: () => onCancel(r) }],
      })
    )
  );
}

export function setPendingBadge(count) {
  for (const id of ['#pending-badge', '#pending-badge-tab']) {
    const el = $(id);
    el.hidden = count === 0;
    el.textContent = String(count);
  }
}

/* ---------- conversation ---------- */
const scroller = () => $('#messages');
const messageList = () => $('#message-list');

export function setChatHeader(username) {
  $('#chat-title').textContent = username;
  $('#chat-avatar-slot').replaceChildren(makeAvatar(username, 'sm'));
  $('#message-input').placeholder = `Message @${username}`;
  $('#convo-start-name').textContent = username;
}

export function resetConversation() {
  messageList().replaceChildren();
  $('#older-btn').hidden = true;
  $('#convo-start').hidden = true;
}

function messageEl(msg, name) {
  const root = document.createElement('div');
  root.className = 'message';
  root.dataset.id = msg.id;
  root.append(makeAvatar(name));

  const body = document.createElement('div');
  body.className = 'message-body';

  const head = document.createElement('div');
  head.className = 'message-head';
  const author = document.createElement('span');
  author.className = 'message-author';
  author.textContent = name;
  const time = document.createElement('time');
  time.className = 'message-time';
  time.textContent = formatTimestamp(msg.timestamp);
  head.append(author, time);

  const text = document.createElement('div');
  text.className = 'message-text';
  text.textContent = msg.text; // textContent, never innerHTML: message text can't inject markup

  body.append(head, text);
  root.append(body);
  return root;
}

function setHasMore(hasMore) {
  $('#older-btn').hidden = !hasMore;
  $('#convo-start').hidden = hasMore;
}

export function renderHistory(messages, hasMore, nameOf) {
  messageList().replaceChildren(...messages.map((m) => messageEl(m, nameOf(m.from))));
  setHasMore(hasMore);
  scroller().scrollTop = scroller().scrollHeight;
}

export function prependHistory(messages, hasMore, nameOf) {
  const box = scroller();
  const before = box.scrollHeight;
  messageList().prepend(...messages.map((m) => messageEl(m, nameOf(m.from))));
  setHasMore(hasMore);
  box.scrollTop += box.scrollHeight - before; // keep the reader's place
}

export function appendMessage(msg, name, mine) {
  const box = scroller();
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  messageList().append(messageEl(msg, name));
  if (mine || nearBottom) box.scrollTop = box.scrollHeight;
}

export function removeMessage(id) {
  messageList().querySelector(`[data-id="${CSS.escape(id)}"]`)?.remove();
}

/* ---------- screen-share source picker ---------- */
export function pickSource(sources) {
  return new Promise((resolve) => {
    const modal = $('#source-modal');
    const grid = $('#source-grid');
    const done = (id) => {
      modal.hidden = true;
      resolve(id);
    };
    grid.replaceChildren(
      ...sources.map((s) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'source';
        const img = new Image();
        img.alt = '';
        if (s.thumbnail) img.src = s.thumbnail;
        const label = document.createElement('span');
        label.textContent = s.name;
        btn.append(img, label);
        btn.addEventListener('click', () => done(s.id));
        return btn;
      })
    );
    $('#source-cancel').onclick = () => done(null);
    modal.hidden = false;
  });
}
