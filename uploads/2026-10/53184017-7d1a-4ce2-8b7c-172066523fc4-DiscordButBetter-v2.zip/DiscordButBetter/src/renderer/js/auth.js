import {
  auth,
  db,
  ref,
  get,
  update,
  serverTimestamp,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  deleteUser,
} from './firebase.js';
import { parseUsername, usernameKey, emailKey, randomTag } from './utils.js';

const MESSAGES = {
  'auth/email-already-in-use': 'That email is already registered.',
  'auth/invalid-email': 'Enter a valid email address.',
  'auth/weak-password': 'Password must be at least 6 characters.',
  'auth/invalid-credential': 'Incorrect email or password.',
  'auth/user-not-found': 'Incorrect email or password.',
  'auth/wrong-password': 'Incorrect email or password.',
  'auth/too-many-requests': 'Too many attempts. Try again in a few minutes.',
  'auth/network-request-failed': 'Network error. Check your connection.',
  'auth/operation-not-allowed': 'Email/Password sign-in is not enabled in the Firebase console.',
  'app/invalid-username':
    'Username must be 2-20 characters (letters, numbers, _ or -), optionally followed by #1234.',
  'app/username-unavailable':
    "That username couldn't be reserved. It's probably taken, or the database rules aren't published yet.",
};

export const authErrorMessage = (err) => MESSAGES[err?.code] ?? err?.message ?? 'Something went wrong.';

const appError = (code) => Object.assign(new Error(code), { code });
const isPermissionError = (e) => /PERMISSION_DENIED/i.test(`${e?.code} ${e?.message}`);

// While registration is running we must not treat the brand-new Auth user as "signed in"
// (the profile doesn't exist yet). The auth listener waits on this promise.
let registration = null;

/**
 * Reserve a username (and the email -> uid lookup) for this user.
 * Both writes are one atomic update: if the name is taken, nothing is written.
 */
async function claimUsername(user, username) {
  const key = usernameKey(username);
  const owner = await get(ref(db, `usernames/${key}`));
  if (owner.exists() && owner.val() !== user.uid) return false;
  try {
    await update(ref(db), {
      [`usernames/${key}`]: user.uid,
      [`emails/${emailKey(user.email)}`]: user.uid,
    });
  } catch (e) {
    if (isPermissionError(e)) return false; // lost a race, or rules not published
    throw e;
  }
  return true;
}

/** Claim a username, then store the profile. A fixed tag is tried once; otherwise random tags are tried. */
async function createProfile(user, name, fixedTag = null) {
  const attempts = fixedTag ? 1 : 12;
  for (let i = 0; i < attempts; i++) {
    const username = `${name}#${fixedTag ?? randomTag()}`;
    if (!(await claimUsername(user, username))) continue;
    try {
      await update(ref(db), {
        [`users/${user.uid}/username`]: username,
        [`users/${user.uid}/createdAt`]: serverTimestamp(),
      });
    } catch (e) {
      // Don't leave a reserved name behind without a profile.
      await update(ref(db), {
        [`usernames/${usernameKey(username)}`]: null,
        [`emails/${emailKey(user.email)}`]: null,
      }).catch(() => {});
      throw e;
    }
    return username;
  }
  throw appError('app/username-unavailable');
}

const sanitizeName = (raw) => {
  const clean = String(raw || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 20);
  return clean.length >= 2 ? clean : 'user';
};

/** Returns the user's username, repairing/creating the profile if needed (e.g. accounts from the old app). */
async function loadOrCreateProfile(user) {
  const snap = await get(ref(db, `users/${user.uid}`));
  const existing = snap.exists() ? snap.val().username : null;

  if (existing && parseUsername(existing, { requireTag: true })) {
    const [nameIdx, emailIdx] = await Promise.all([
      get(ref(db, `usernames/${usernameKey(existing)}`)),
      get(ref(db, `emails/${emailKey(user.email)}`)),
    ]);
    if (nameIdx.exists() && nameIdx.val() !== user.uid) {
      throw new Error('Your username is registered to a different account. Please contact the app owner.');
    }
    if (!nameIdx.exists() || !emailIdx.exists()) await claimUsername(user, existing);
    return existing;
  }

  const base = sanitizeName(existing ? existing.split('#')[0] : user.email.split('@')[0]);
  return createProfile(user, base);
}

export function register({ username, email, password }) {
  const parsed = parseUsername(username);
  if (!parsed) return Promise.reject(appError('app/invalid-username'));

  const run = (async () => {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
    try {
      await createProfile(cred.user, parsed.name, parsed.tag);
    } catch (err) {
      await deleteUser(cred.user).catch(() => {}); // roll back the half-created account
      throw err;
    }
  })();

  registration = run.catch(() => {});
  return run;
}

export const login = (email, password) => signInWithEmailAndPassword(auth, email.trim(), password);
export const logout = () => signOut(auth);

export function watchAuth({ onSignedIn, onSignedOut, onError }) {
  onAuthStateChanged(auth, async () => {
    if (registration) await registration;
    const user = auth.currentUser;
    if (!user) return onSignedOut();
    try {
      const username = await loadOrCreateProfile(user);
      if (auth.currentUser?.uid !== user.uid) return; // user changed while we were loading
      onSignedIn({ uid: user.uid, email: user.email, username });
    } catch (err) {
      onError(err);
      await signOut(auth).catch(() => {});
    }
  });
}
